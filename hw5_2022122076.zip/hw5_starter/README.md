## Setup

Start with your `aai4160` conda environment, or create a new conda environment based on the instructions provided to you in homework 1.

Then, run the following commands when you're under the `hw5_starter/` folder.

```
conda activate [your_env]
pip install -r requirements.txt
pip install -e .
```

## TODOs

The TODOs and descriptions for code that needs to be implemented has been provided in the homework PDF.
