# setup.py
from setuptools import setup

setup(
    name='aai4160',
    version='0.1.0',
    packages=['aai4160'],
)
